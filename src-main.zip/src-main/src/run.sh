#!/usr/bin/env bash
#=================================================================
# Automated OpenFOAM Meshing & Simulation Pipeline
#-----------------------------------------------------------------
# 1) STL preprocessing 
# 2) Create cases & mesh dicts
# 3) Run blockMesh & surfaceFeatureExtract
# 4) Run snappyHexMesh in series or parallel + reconstruct
# 5) Finalize meshes & create .foam files
# 6) Run CFD solver
#=================================================================

set -euo pipefail

#-----------------------------------------------------------------
# CONFIGURATION: define directory structure and script paths
#-----------------------------------------------------------------
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
INPUT_STL="$SCRIPT_DIR/inputSTL"
MESH_TMPL="$SCRIPT_DIR/mesh"
SCRIPTS="$SCRIPT_DIR/scripts"
TEMPLATE_CASE="$SCRIPT_DIR/templateCase"
CASES="$SCRIPT_DIR/cases"

IMPORT_SCRIPT="$SCRIPTS/import_geometry.py"
BMD_SCRIPT="$SCRIPTS/generate_blockMeshDict.py"
CASE_SCRIPT="$SCRIPTS/case_structure.py"

#-----------------------------------------------------------------
# UTILITY FUNCTIONS
#-----------------------------------------------------------------
print_section(){
  echo
  echo "================================================================"
  echo "==> $1"
  echo "================================================================"
}

run_and_log(){
  local cmd="$1"; shift
  local wd="$1";   shift
  local logf="$1"; shift
  echo "⌛ Running in $(basename "$wd"): $cmd"
  (cd "$wd" && eval "$cmd" &> "$logf")
  echo "✔️  Completed: $cmd"
}


#-----------------------------------------------------------------
# 1) Create cases & mesh dicts
#-----------------------------------------------------------------
print_section "1. Generating OpenFOAM case structure"

# ask single-core vs multi-core
read -rp "Run snappyHexMesh in parallel? [y/N]: " runParallel
if [[ "$runParallel" =~ ^[Yy]$ ]]; then
  read -rp "How many cores for each case? [default 4]: " nproc
  nproc=${nproc:-4}
  echo "Using $nproc cores for parallel snappyHexMesh"
else
  nproc=1
fi

python3 "$CASE_SCRIPT"
echo "✔️  case_structure.py completed"

#-----------------------------------------------------------------
# 2) Run blockMesh & surfaceFeatureExtract in each case
#-----------------------------------------------------------------
print_section "2. Running blockMesh & surfaceFeatureExtract"
for case in "$CASES"/case_*; do
  [[ -d "$case" ]] || continue
  run_and_log "blockMesh"             "$case" "log_blockMesh.txt"
  run_and_log "surfaceFeatureExtract" "$case" "log_surfaceFeatureExtract.txt"
done

#-----------------------------------------------------------------
# 3) Run snappyHexMesh in series or parallel + reconstruct
#-----------------------------------------------------------------
print_section "3. Running snappyHexMesh"
if [[ "$runParallel" =~ ^[Yy]$ ]]; then
  for case in "$CASES"/case_*; do
    [[ -d "$case" ]] || continue
    run_and_log "decomposePar" "$case" "log_decomposePar.txt"
    run_and_log "mpirun -np $nproc snappyHexMesh -dict system/snappyHexMeshDict -parallel -overwrite" "$case" "log_snappyHexMesh.txt"
    run_and_log "reconstructParMesh -constant" "$case" "log_reconstructParMesh.txt"
    rm -rf "$case"/processor*
  done
  echo "✔️  All parallel snappyHexMesh jobs completed"
else
  for case in "$CASES"/case_*; do
    [[ -d "$case" ]] || continue
    run_and_log "snappyHexMesh -dict system/snappyHexMeshDict -overwrite" "$case" "log_snappyHexMesh.txt"
  done
  echo "✔️  All single-core snappyHexMesh jobs completed"
fi

#-----------------------------------------------------------------
# 4) Finalize meshes & create .foam files
#-----------------------------------------------------------------
print_section "4. Finalizing meshes"
for case in "$CASES"/case_*; do
  [[ -d "$case" ]] || continue
  foamfile="$case/$(basename "$case").foam"
  [[ -f "$foamfile" ]] || { touch "$foamfile"; echo "✔️  Created foam file: $(basename "$foamfile")"; }
done

#-----------------------------------------------------------------
# 5) Run CFD solver (optional parallel)
#-----------------------------------------------------------------
print_section "5. Running CFD solver"
ctrl="$TEMPLATE_CASE/system/controlDict"
solver=$(grep -Po '(?<=application\s+)[^;]+' "$ctrl" || echo pimpleFoam)    # echo simpleFoam
read -rp "Run solver in parallel with $nproc cores? [y/N]: " runSol
for case in "$CASES"/case_*; do
  [[ -d "$case" ]] || continue
  if [[ "$runSol" =~ ^[Yy]$ ]]; then
    run_and_log "decomposePar"      "$case" "log_decomposePar_sim.txt"
    run_and_log "mpirun -np $nproc $solver -parallel" "$case" "log_solver.txt"
    run_and_log "reconstructPar"    "$case" "log_reconstructSim.txt"
  else
    run_and_log "$solver"           "$case" "log_solver.txt"
  fi
done

print_section "PIPELINE COMPLETED SUCCESSFULLY!"
