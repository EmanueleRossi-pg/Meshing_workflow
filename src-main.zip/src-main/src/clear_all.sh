#!/bin/bash

# ===== SETUP =====
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
CASES_DIR="$SCRIPT_DIR/cases"
OUTPUT_DIR="$SCRIPT_DIR/scripts/output"

# ===== FUNZIONE PER RIMOZIONE =====
remove_if_exists() {
  local path="$1"
  local name="$2"

  if [ -d "$path" ]; then
    rm -rf "$path"
    echo "🗑️  Deleted: $name"
  else
    echo "ℹ️  Not found: $name"
  fi
}

echo "🚨 This will permanently delete the following folders:"
echo "- $CASES_DIR"
echo "- $OUTPUT_DIR"
read -p "Are you sure? [y/N]: " confirm

if [[ "$confirm" =~ ^[Yy]$ ]]; then
  remove_if_exists "$CASES_DIR" "cases/"
  remove_if_exists "$OUTPUT_DIR" "scripts/output/"
  echo "✅ Cleanup complete."
else
  echo "❌ Aborted by user."
fi

